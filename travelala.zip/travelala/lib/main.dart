import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:travelala/auth/wrapper.dart';
import 'package:travelala/services/auth_service.dart';
// import 'package:travelala/ui/HomePage.dart';
// import 'package:travelala/ui/HomePage.dart';
// import 'package:travelala/ui/home.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  @override
  Widget build(BuildContext context) {
    return StreamProvider.value(
      value: AuthServices.firebaseUserStream,
      child: MaterialApp(
        home: Wrapper(),
      ),
    );
  }
}

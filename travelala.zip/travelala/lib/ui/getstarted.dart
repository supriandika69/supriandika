import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:travelala/auth/login_page.dart';

class GetStarted extends StatefulWidget {
  @override
  _GetStartedState createState() => _GetStartedState();
}

class _GetStartedState extends State<GetStarted> {
  @override
  Widget build(BuildContext context) {
    Widget mycarousel = Container(
      height: 400,
      margin: EdgeInsets.only(top: 50),
      child: Carousel(
        images: [
          Column(
            children: <Widget>[
              Text("Titile 1",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              Text(
                "Keterangan 1",
                style: TextStyle(fontSize: 25, color: Colors.white),
              )
            ],
          ),
          Column(
            children: <Widget>[
              Text("Titile 2",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              Text(
                "Keterangan 2",
                style: TextStyle(fontSize: 25, color: Colors.white),
              )
            ],
          ),
          Column(
            children: <Widget>[
              Text("Titile 3",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              Text(
                "Keterangan 3",
                style: TextStyle(fontSize: 25, color: Colors.white),
              )
            ],
          ),
        ],
        showIndicator: false,
        boxFit: BoxFit.fitHeight,
        autoplay: true,
      ),
    );
    return MaterialApp(
      home: Scaffold(
          body: Stack(
        children: <Widget>[
          Container(
            child: Image(
              image: AssetImage('images/splash.jpg'),
              fit: BoxFit.fill,
            ),
          ),
          Align(
            alignment: Alignment(0, 5),
            child: ListView(
              padding: EdgeInsets.only(top: 250),
              children: <Widget>[mycarousel],
            ),
          ),
          Align(
            alignment: Alignment(0, 0.7),
            child: Container(
              width: 200,
              height: 50,
              child: RaisedButton(
                  child: Text(
                    "Mulai",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                    ),
                  ),
                  color: Color(0xFFFF7D59),
                  onPressed: () {
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) {
                      return LoginPage();
                    }));
                  }),
            ),
          ),
        ],
      )),
    );
  }
}

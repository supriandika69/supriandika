import 'package:flutter/material.dart';
import 'package:travelala/models/place.dart';
import 'package:travelala/services/firestore_get.dart';
import 'package:travelala/widgets/card.dart';

class ListPage extends StatefulWidget {
  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: StreamBuilder(
            stream: FireStoreGet().getPlaces(),
            builder:
                (BuildContext context, AsyncSnapshot<List<Place>> snapshot) {
              return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    Place place = snapshot.data[index];
                    // return ListTile(
                    //   title: Text(place.name),
                    //   subtitle: Text(place.location),

                    // );
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: MyCard(
                        place: place,
                      ),
                    );
                  });
            }));
  }
}

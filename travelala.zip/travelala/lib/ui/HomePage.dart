import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
// import 'package:travelala/services/auth_service.dart';
// import 'package:travelala/models/place.dart';
import 'package:travelala/ui/add_place.dart';
import 'package:travelala/ui/grid_page.dart';
import 'package:travelala/ui/list_page.dart';
import 'package:travelala/widgets/my_drawer.dart';

class HomePage extends StatefulWidget {
  // final Place place;
  final FirebaseUser user;
  const HomePage({this.user});
  @override
  _HomePageState createState() => _HomePageState(user: user);
}

class _HomePageState extends State<HomePage> {
  final FirebaseUser user;
  final FirebaseMessaging _messaging = FirebaseMessaging();
  _HomePageState({this.user});

  @override
  void initState() {
    super.initState();
    _messaging.getToken().then((token){
      print(token);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
          length: 3,
          child: Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.white,
                bottom: TabBar(
                  tabs: [
                    Tab(
                        icon: Icon(
                      Icons.list,
                      color: Colors.black,
                    )),
                    Tab(
                        icon: Icon(
                      Icons.grid_on,
                      color: Colors.black,
                    )),
                    Tab(
                        icon: Icon(
                      Icons.add_box,
                      color: Colors.black,
                    )),
                  ],
                ),
                title: Text(
                  'Travelala',
                  style: TextStyle(color: Colors.black),
                ),
              ),
              body: TabBarView(
                children: [
                  ListPage(),
                  GridPage(),
                  AddPlace(),
                ],
              ),
              drawer: MyDrawer(
                email: user.email,
              ))),
    );
  }
}

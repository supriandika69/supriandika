import 'package:flutter/material.dart';
// import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:travelala/models/place.dart';
import 'package:travelala/services/firestore_get.dart';
import 'package:travelala/ui/detail_page.dart';
// import 'package:travelala/widgets/card.dart';

class GridPage extends StatefulWidget {
  @override
  _GridPageState createState() => _GridPageState();
}

class _GridPageState extends State<GridPage> {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: StreamBuilder(
            stream: FireStoreGet().getPlaces(),
            builder:
                (BuildContext context, AsyncSnapshot<List<Place>> snapshot) {
              return GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3),
                  itemCount: snapshot.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    Place place = snapshot.data[index];
                    return Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (_)=>DetailPage(place: place,)));
                        },
                        child: Container(
                          width: 50,
                          height: 50,
                          child: Image(
                            image: NetworkImage(place.imageUrl),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    );
                  });
            }));
  }
}

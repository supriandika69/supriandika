import 'package:flutter/material.dart';
import 'package:travelala/models/place.dart';

class DetailPage extends StatefulWidget {
  final Place place;
  DetailPage({this.place});
  @override
  _DetailPageState createState() => _DetailPageState(place: place);
}

class _DetailPageState extends State<DetailPage> {
  final Place place;
  _DetailPageState({@required this.place});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          body: ListView(
        children: <Widget>[
          Container(
            width: 360,
            height: 800,
            color: Colors.black12,
            child: Stack(
              children: <Widget>[
                Positioned(
                    top: 0,
                    child: Container(
                      width: 360,
                      height: 350,
                      decoration: BoxDecoration(
                        color: Colors.black12,
                      ),
                      child: Image(
                        image: NetworkImage(place.imageUrl),
                        fit: BoxFit.cover,
                      ),
                    )),
                Positioned(
                    top: 300,
                    child: Container(
                      width: 360,
                      height: 370,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: 340,
                              height: 50,
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.black12))),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  place.name,
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: 340,
                              height: 100,
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom:
                                          BorderSide(color: Colors.black12))),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  place.depcription,
                                  style: TextStyle(fontSize: 17),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 5,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 16, right: 16),
                            child: Container(
                              width: 340,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Info Lengkap :",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 17),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      children: <Widget>[
                                        Icon(Icons.attach_money),
                                        Text(
                                          "Tiket Masuk " + place.price,
                                          style: TextStyle(fontSize: 17),
                                        )
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      children: <Widget>[
                                        Icon(Icons.location_on),
                                        Text(
                                          place.location,
                                          style: TextStyle(fontSize: 17),
                                        )
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 80),
                                    child: Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                          size: 30,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                          size: 30,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                          size: 30,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                          size: 30,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                          size: 30,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    )),Positioned(
                      top: 620,
                      child: Container(
                      padding: EdgeInsets.all(16),
                      width: 360,
                      height: 200,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.amber
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              border: Border(bottom: BorderSide(color: Colors.white))
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text("Tips", style: TextStyle(fontSize: 20, color: Colors.white),),
                                Icon(Icons.lightbulb_outline, color: Colors.white,)
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 10),
                            child: Text("Selalu hormati budaya lokal. Kenakan pakaian yang sesuai ketika memasuki tempat yang disakralkan.",
                            style: TextStyle(color: Colors.white, fontSize: 17), maxLines: 5, textAlign: TextAlign.start),
                          )
                        ],
                      ),
                    ))
              ],
            ),
          )
        ],
      )),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:travelala/models/place.dart';
import 'package:travelala/services/firestore_service.dart';
import 'dart:io';

import 'package:travelala/widgets/image_picker.dart';

class EditPlace extends StatefulWidget {
  final Place place;
  const EditPlace({this.place});

  @override
  _EditPlaceState createState() => _EditPlaceState(place: place);
}

class _EditPlaceState extends State<EditPlace> {
  final Place place;
  _EditPlaceState({this.place});
  TextEditingController _nameCont ;
  TextEditingController _priceCont ;
  TextEditingController _locationCont ;
  TextEditingController _depcriptionCont;

  @override
  void initState() {
    super.initState();
    _nameCont =
        TextEditingController(text: place.name);
    _priceCont =
        TextEditingController(text: place.price);
    _locationCont =
      TextEditingController(text: place.location);
    _depcriptionCont =
      TextEditingController(text: place.depcription);
  }
  
  String imagePath="i";

  File file;
  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
        child: ListView(
          children: <Widget>[
            // Text(
            //   "Tambah Data Tempat",
            //   style: TextStyle(color: Colors.black, fontSize: 20),
            // ),
            (imagePath == null
                ? Container(
                    width: 300,
                    height: 270,
                    child: Center(
                      child: IconButton(
                          icon: Icon(
                            Icons.add_a_photo,
                            size: 50,
                            color: Colors.white,
                          ),
                          onPressed: () async {
                            file = await getImage();
                            imagePath =
                                await FirestoreService.uploadImage(file);
                            setState(() {});
                          }),
                    ),
                    decoration: BoxDecoration(
                        color: Colors.black26,
                        borderRadius: BorderRadius.circular(10)),
                  )
                : Container(
                    width: 300,
                    height: 270,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(10)),
                    // child: Image.network(imagePath),
                    child: Image(
                      image: NetworkImage(place.imageUrl),
                      loadingBuilder: (BuildContext contex, Widget child,
                          ImageChunkEvent loadingProgress) {
                        if (loadingProgress == null) {
                          return child;
                        }
                        return Center(
                          child: CircularProgressIndicator(
                            value: loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded /
                                    loadingProgress.expectedTotalBytes
                                : null,
                          ),
                        );
                      },
                      fit: BoxFit.cover,
                    ))),
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: TextFormField(
                controller: _nameCont,
                decoration: InputDecoration(
                    labelText: 'Nama Tempat',
                    prefixIcon: Icon(Icons.location_city)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: TextFormField(
                controller: _locationCont,
                decoration: InputDecoration(
                    labelText: 'Lokasi', prefixIcon: Icon(Icons.place)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: TextFormField(
                controller: _priceCont,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    labelText: 'Harga Tiket Masuk',
                    prefixIcon: Icon(Icons.attach_money)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 10),
              child: TextFormField(
                maxLines: 3,
                controller: _depcriptionCont,
                decoration: InputDecoration(
                    labelText: 'Deskripsi',
                    prefixIcon: Icon(Icons.description)),
              ),
            ),
            Center(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Container(
                      height: 50,
                      width: 300,
                      decoration: BoxDecoration(
                        color: Colors.black12,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: RaisedButton(
                        onPressed: () {
                          Place place = Place(
                            name: _nameCont.text,
                            price: _priceCont.text,
                            location: _locationCont.text,
                            depcription: _depcriptionCont.text,
                            imageUrl: imagePath,
                  
                          );
                          FirestoreService.addPlace(place);
                        },
                        child: Text("Simpan"),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: Container(
                      height: 50,
                      width: 300,
                      decoration: BoxDecoration(
                          color: Colors.black12,
                          borderRadius: BorderRadius.circular(15)),
                      child: RaisedButton(
                        onPressed: () {},
                        child: Text("Batal"),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

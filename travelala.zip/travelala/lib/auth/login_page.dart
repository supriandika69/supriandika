import 'package:flutter/material.dart';
import 'package:travelala/services/auth_service.dart';

import 'signUp_page.dart';

class LoginPage extends StatelessWidget {
  TextEditingController _emailCont = TextEditingController();
  TextEditingController _passCont = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(
                Icons.card_travel,
                color: Colors.amber,
                size: 50,
              ),
              Text(
                "Travelala",
                style: TextStyle(fontSize: 25),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 50),
                child: Container(
                  width: 300,
                  height: 50,
                  child: TextField(
                    controller: _emailCont,
                    decoration: InputDecoration(
                        prefixIcon: Icon(Icons.people), labelText: "email"),
                  ),
                ),
              ),
              Container(
                width: 300,
                height: 50,
                child: TextField(
                  controller: _passCont,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.lock),
                    labelText: "password",
                  ),
                  obscureText: true,
                ),
              ),
              Container(
                  width: 150,
                  height: 60,
                  padding: EdgeInsets.only(top: 20),
                  child: OutlineButton(
                    onPressed: () async{
                     await AuthServices.signIn(_emailCont.text, _passCont.text);
                    },
                    child: Text("Login"),
                  )),
              Padding(
                padding: const EdgeInsets.only(right: 25, left: 25, top: 100),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    GestureDetector(
                        onTap: () {
                          Navigator.push(context,
                              MaterialPageRoute(builder: (_) => SignUpPage()));
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(color: Colors.blue),
                        )),
                    Text(
                      "Butuh Bantuan?",
                      style: TextStyle(color: Colors.blue),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:firebase_in_app_messaging/firebase_in_app_messaging.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:travelala/services/auth_service.dart';

class MyDrawer extends StatelessWidget {
  MyDrawer({this.email});

  final String email;
  final FirebaseMessaging _messaging = FirebaseMessaging();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: <Widget>[
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(20),
            color: Theme.of(context).primaryColor,
            child: Center(
              child: Column(
                children: <Widget>[
                  Container(
                    width: 100,
                    height: 100,
                    margin: EdgeInsets.only(top: 30, bottom: 10),
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white),
                  ),
                  Text(
                    "User",
                    style: TextStyle(fontSize: 22, color: Colors.white),
                  ),
                  Text(
                    email,
                    style: TextStyle(color: Colors.white),
                  )
                ],
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text(
              "About",
              style: TextStyle(fontSize: 18),
            ),
            onTap: null,
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text(
              "Settings",
              style: TextStyle(fontSize: 18),
            ),
            onTap: null,
          ),
          ListTile(
            leading: Icon(Icons.arrow_back),
            title: Text(
              "Logout",
              style: TextStyle(fontSize: 18),
            ),
            onTap: (){
              _signOut(context);
            },
          ),
        ],
      ),
    );
  }

    void _signOut(BuildContext context) async {
    if (await _showConfirmationDialog(context)) {
     AuthServices.signOut();
    }
  }

  Future<bool> _showConfirmationDialog(BuildContext context) async {
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => AlertDialog(
        content: Text("Yakin Keluar??"),
        actions: <Widget>[
          FlatButton(
            textColor: Colors.red,
            onPressed: () => Navigator.pop(context, true),
            child: Text("Keluar"),
          ),
          FlatButton(
            textColor: Colors.black,
            onPressed: () => Navigator.pop(context, false),
            child: Text("Batal"),
          ),
        ],
      ),
    );
  }
}

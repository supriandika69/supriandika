import 'package:image_picker/image_picker.dart';
import 'dart:io';

Future<File> getImage()async{
  return await ImagePicker.pickImage(source: ImageSource.gallery);
}
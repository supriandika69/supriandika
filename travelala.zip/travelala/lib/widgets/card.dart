import 'package:flutter/material.dart';
import 'package:travelala/models/place.dart';
import 'package:travelala/services/firestore_get.dart';
import 'package:travelala/ui/detail_page.dart';
import 'package:travelala/ui/edit_page.dart';

class MyCard extends StatelessWidget {
  final Place place;
  MyCard({@required this.place});

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(10),
            width: 350,
            height: 400,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black12)),
            child: Column(
              children: <Widget>[
                Container(
                  width: 300,
                  height: 40,
                  decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: Colors.black12)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            place.name,
                            style: TextStyle(fontSize: 17),
                          ),
                          Text(
                            place.location,
                            style: TextStyle(fontSize: 10),
                          ),
                        ],
                      ),
                      Row(
                        
                        children: <Widget>[
                          IconButton(
                              icon: Icon(Icons.delete, size: 20,),
                              onPressed: () {
                                _deletePlaces(context, place.id);
                              }),
                          IconButton(
                              icon: Icon(Icons.edit, size: 20,),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) => EditPlace(
                                              place: place,
                                            )));
                              }),
                        ],
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => DetailPage(
                                    place: place,
                                  )));
                    },
                    child: Container(
                      width: 300,
                      height: 250,
                      child: Image(
                          image: NetworkImage(place.imageUrl),
                          loadingBuilder: (BuildContext contex, Widget child,
                              ImageChunkEvent loadingProgress) {
                            if (loadingProgress == null) {
                              return child;
                            }
                            return Center(
                              child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes !=
                                        null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                        loadingProgress.expectedTotalBytes
                                    : null,
                              ),
                            );
                          }),
                    ),
                  ),
                ),
                Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.thumb_up,
                          size: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 10, left: 10),
                          child: Icon(
                            Icons.comment,
                            size: 20,
                          ),
                        ),
                        Icon(
                          Icons.share,
                          size: 20,
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Text(
                        place.depcription,
                        style: TextStyle(fontSize: 15, color: Colors.black),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _deletePlaces(BuildContext context, String id) async {
    if (await _showConfirmationDialog(context)) {
      try {
        await FireStoreGet().deletePlace(id);
      } catch (e) {
        print(e);
      }
    }
  }

  Future<bool> _showConfirmationDialog(BuildContext context) async {
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => AlertDialog(
        content: Text("Yakin Hapus?"),
        actions: <Widget>[
          FlatButton(
            textColor: Colors.red,
            onPressed: () => Navigator.pop(context, true),
            child: Text("Hapus"),
          ),
          FlatButton(
            textColor: Colors.black,
            onPressed: () => Navigator.pop(context, false),
            child: Text("Batal"),
          ),
        ],
      ),
    );
  }
}

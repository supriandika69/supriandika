class Place{
  final String id;
  final String name;
  final String location;
  final String price;
  final String depcription;
  final String imageUrl;

  Place({this.id, this.name, this.location, this.price, this.depcription, this.imageUrl});

  Place.fromMap(Map<String,dynamic> data, String id):
    name=data["name"],
    location=data["location"],
    price=data["price"],
    depcription=data["depcription"],
    imageUrl=data["imageUrl"],
    id=id;

  Map<String, dynamic> toMap(){
    return {
      "name" : name,
      "location" : location,
      "price" : price,
      "depcription" : depcription,
      "imageUrl" : imageUrl
    };
  } 

}
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:travelala/models/place.dart';

class FireStoreGet {
  static final FireStoreGet _firestoreService = FireStoreGet._internal();
  Firestore _db = Firestore.instance;

  FireStoreGet._internal();
  factory FireStoreGet() {
    return _firestoreService;
  }

  Stream<List<Place>> getPlaces() {
    return _db.collection('places').snapshots().map(
          (snapshot) => snapshot.documents
              .map(
                (doc) => Place.fromMap(doc.data, doc.documentID),
              )
              .toList(),
        );
  }

  Future<void> deletePlace(String id) {
    return _db.collection('places').document(id).delete();
  }
}
